// ============================================================
// 辽宁中医嘉和医院 · 标准化培训地图 — 模块数据层
// 版本: V1.0 | 2026-06-05
// ============================================================

const TRAINING_DOMAINS = {
  insurance: {
    id: 'insurance',
    name: '医保合规',
    icon: '🛡️',
    color: '#1a5276',
    desc: '医保政策、飞行检查、编码规范、收费合规'
  },
  medical_record: {
    id: 'medical_record',
    name: '病历质控',
    icon: '📋',
    color: '#2e7d32',
    desc: '病历书写规范、等级判定、质控流程、闭环整改'
  },
  clinical: {
    id: 'clinical',
    name: '临床技能',
    icon: '🩺',
    color: '#c62828',
    desc: '急救流程、临床路径、合理用药、医患沟通'
  },
  tcm: {
    id: 'tcm',
    name: '中医特色',
    icon: '🌿',
    color: '#6a1b9a',
    desc: '针灸推拿、中药管理、康复评定、优势病种'
  },
  regulation: {
    id: 'regulation',
    name: '制度规范',
    icon: '📜',
    color: '#e65100',
    desc: '核心制度、岗前培训、绩效考核、法规教育'
  },
  infection: {
    id: 'infection',
    name: '院感安全',
    icon: '🔬',
    color: '#00838f',
    desc: '无菌操作、医疗废物、职业暴露、应急预案'
  }
};

const AUDIENCE_LEVELS = {
  all: { id: 'all', name: '全院必修', icon: '🏥' },
  doctor: { id: 'doctor', name: '全体医师', icon: '👨‍⚕️' },
  nurse: { id: 'nurse', name: '全体护士', icon: '👩‍⚕️' },
  dept: { id: 'dept', name: '科室专项', icon: '🏢' },
  role: { id: 'role', name: '角色必修', icon: '👤' },
  newcomer: { id: 'newcomer', name: '新员工', icon: '🌱' }
};

const STATUS_TAGS = {
  complete:  { id: 'complete',  label: '材料齐全', icon: '✅', cls: 'badge-success' },
  framework: { id: 'framework', label: '框架已有', icon: '🔶', cls: 'badge-warning' },
  extend:    { id: 'extend',    label: '从文档延伸', icon: '📄', cls: 'badge-info' },
  planned:   { id: 'planned',   label: '待开发', icon: '📝', cls: 'badge-danger' }
};

const TRAINING_MODULES = [
  // ======================== 医保合规 ========================
  {
    id: 'm01',
    domain: 'insurance',
    title: '医保飞行检查迎检全流程',
    subtitle: '五阶迎检：自查→入场→应对→收尾→整改闭环',
    audience: ['all'],
    format: ['线下授课', '实操演练'],
    duration: 90,
    status: 'extend',
    month: 8,
    prerequisite: [],
    sourceDoc: 'CC Switch 医保迎检自查流程图',
    filePaths: [
      { label: '📊 培训PPT', path: 'ppts/m01-医保飞行检查迎检全流程.pptx' },
      { label: '📊 迎检流程图(MD)', path: '../辽宁中医嘉和医院_医保迎检自查流程图.md' },
      { label: '🌐 可视化系统', path: '../index.html' }
    ],
    keywords: ['飞检', '自查自纠', '十要十不要', '话术'],
    blueprintPath: 'plans/m01-医保飞检迎检-培训讲稿骨架.md'
  },
  {
    id: 'm02',
    domain: 'insurance',
    title: '穴位埋线门诊合规操作',
    subtitle: '资质·收费·操作·院感·文书全维度自查',
    audience: ['dept'],
    targetDept: '针灸科',
    format: ['线下授课', '实操演练'],
    duration: 60,
    status: 'extend',
    month: 9,
    prerequisite: [],
    sourceDoc: 'CC Switch 穴位埋线门诊自查手册',
    filePaths: [
      { label: '📊 培训PPT', path: 'ppts/m02-穴位埋线门诊合规操作.pptx' },
      { label: '📊 自查手册(MD)', path: '../辽宁中医嘉和医院_穴位埋线门诊自查手册.md' },
      { label: '🌐 可视化系统', path: '../index.html' }
    ],
    keywords: ['穴位埋线', '按次收费', '无菌操作', '知情同意'],
    blueprintPath: 'plans/m02-穴位埋线合规-培训讲稿骨架.md'
  },
  {
    id: 'm03',
    domain: 'insurance',
    title: '心电图室合规设置方案',
    subtitle: '资质要求·辽宁特定规·4种实施方案',
    audience: ['dept'],
    targetDept: '心电图室/医务科',
    format: ['线下授课'],
    duration: 45,
    status: 'extend',
    month: 10,
    prerequisite: [],
    sourceDoc: 'CC Switch 心电图室合规方案',
    filePaths: [
      { label: '📊 培训PPT', path: 'ppts/m03-心电图室合规设置方案.pptx' },
      { label: '📊 合规方案(MD)', path: '../辽宁中医嘉和医院_心电图室合规方案_辽宁省标准.md' }
    ],
    keywords: ['心电图', '执业范围', '辽卫办发2016-25号', '心电诊断'],
    blueprintPath: 'plans/m03-心电图合规-培训讲稿骨架.md'
  },
  {
    id: 'm04',
    domain: 'insurance',
    title: 'ICD-10诊断编码填报修订（2026版）',
    subtitle: '辽宁省医保结算清单ICD-10填报新规',
    audience: ['dept', 'doctor'],
    targetDept: '病案室/医保办',
    format: ['线下授课', '考核测评'],
    duration: 120,
    status: 'complete',
    month: 8,
    prerequisite: [],
    filePaths: [
      { label: '📊 培训PPT', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/3、《辽宁省医疗保障基金结算清单及编码填报管理规范(2026版) 》ICD-10填报修订部分.pptx' },
      { label: '📄 培训PDF', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/3、《辽宁省医疗保障基金结算清单及编码填报管理规范(2026版) 》ICD-10填报修订部分.pdf' },
      { label: '📊 诊断编码表', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/诊断编码.xlsx' }
    ],
    keywords: ['ICD-10', '医保2.0', '诊断编码', '辽宁省规范']
  },
  {
    id: 'm05',
    domain: 'insurance',
    title: 'ICD-9-CM-3手术编码填报修订（2026版）',
    subtitle: '辽宁省医保结算清单手术编码新规',
    audience: ['dept', 'doctor'],
    targetDept: '病案室/骨外科',
    format: ['线下授课', '考核测评'],
    duration: 90,
    status: 'complete',
    month: 8,
    prerequisite: ['m04'],
    filePaths: [
      { label: '📊 培训PPT', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/4、《辽宁省医疗保障基金结算清单及编码填报管理规范（2026版）》_ICD-9-CM-3填报修订部分.pptx' },
      { label: '📄 培训PDF', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/4、《辽宁省医疗保障基金结算清单及编码填报管理规范（2026版）》_ICD-9-CM-3填报修订部分.pdf' },
      { label: '📊 手术编码表', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/手术操作编码.xlsx' }
    ],
    keywords: ['ICD-9-CM-3', '手术编码', '医保2.0', '辽宁省规范']
  },
  {
    id: 'm06',
    domain: 'insurance',
    title: '辽宁省医保结算清单管理修订（2026版）',
    subtitle: '管理部分修订内容：填报流程与责任分工',
    audience: ['dept'],
    targetDept: '病案室/医保办',
    format: ['线下授课'],
    duration: 60,
    status: 'complete',
    month: 8,
    prerequisite: [],
    filePaths: [
      { label: '📊 培训PPT', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/1、《辽宁省医疗保障基金结算清单及编码填报管理规范(2026版)》管理部分修订内容.pptx' },
      { label: '📄 培训PDF', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/1、《辽宁省医疗保障基金结算清单及编码填报管理规范(2026版)》管理部分修订内容.pdf' }
    ],
    keywords: ['结算清单', '管理规范', '填报流程']
  },
  {
    id: 'm07',
    domain: 'insurance',
    title: '诊断及手术填报重点（2026版）',
    subtitle: '辽宁省医保结算清单诊断与手术填报核心要点',
    audience: ['dept', 'doctor'],
    targetDept: '病案室/全院医师',
    format: ['线下授课'],
    duration: 90,
    status: 'complete',
    month: 8,
    prerequisite: ['m04'],
    filePaths: [
      { label: '📊 培训PPT', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/2、《辽宁省医疗保障基金结算清单及编码填报管理规范（2026版）》诊断及手术填报重点.pptx' },
      { label: '📄 培训PDF', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/2、《辽宁省医疗保障基金结算清单及编码填报管理规范（2026版）》诊断及手术填报重点.pdf' }
    ],
    keywords: ['诊断填报', '手术填报', '结算清单']
  },

  // ======================== 病历质控 ========================
  {
    id: 'm08',
    domain: 'medical_record',
    title: '病历质控：从红线到闭环',
    subtitle: '六大质控模块·五条丙级红线·Top10高频缺陷·三级质控体系',
    audience: ['all', 'doctor'],
    format: ['线上视频', '线下授课', '考核测评'],
    duration: 30,
    status: 'complete',
    month: 7,
    prerequisite: [],
    filePaths: [
      { label: '🎬 视频制作工作流', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/病历质控/视频制作工作流.md' },
      { label: '📝 培训讲稿(MD)', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/病历质控/病历质控培训讲稿.md' },
      { label: '📄 字幕文件(SRT)', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/病历质控/病历质控培训字幕.srt' },
      { label: '🖼️ 幻灯片(新)', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/病历质控/新/' },
      { label: '📊 质控评分方案', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/二级中医康复病历质控评分方案脚本.xlsx' }
    ],
    keywords: ['病历质控', '甲级≥90', '丙级红线', 'SMART目标', '康复评定']
  },
  {
    id: 'm09',
    domain: 'medical_record',
    title: '病历质控：从红线到闭环（综合版）',
    subtitle: '全院适用的病历质控培训，非康复专项',
    audience: ['all', 'doctor'],
    format: ['线下授课'],
    duration: 60,
    status: 'complete',
    month: 7,
    prerequisite: [],
    filePaths: [
      { label: '📊 培训PPT', path: 'C:/Users/86132/Desktop/病历质控：从红线到闭环.pptx' }
    ],
    keywords: ['病历质控', '丙级红线', '甲级率', '质控闭环']
  },

  // ======================== 临床技能 ========================
  {
    id: 'm10',
    domain: 'clinical',
    title: '临床常见急症标准化诊疗与急救流程',
    subtitle: '急症识别→标准化处置→急救操作→团队协作',
    audience: ['all', 'doctor', 'nurse'],
    format: ['线下授课', '实操演练', '考核测评'],
    duration: 120,
    status: 'complete',
    month: 7,
    prerequisite: [],
    filePaths: [
      { label: '📊 培训PPTX', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/临床常见急症标准化诊疗与急救流程/临床常见急症标准化诊疗与急救流程.pptx' },
      { label: '📝 PPT脚本', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/临床常见急症标准化诊疗与急救流程/辽宁中医嘉和医院临床常见急症标准化诊疗与急救流程培训PPT脚本.docx' },
      { label: '🎤 培训讲稿', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/临床常见急症标准化诊疗与急救流程/临床常见急症标准化诊疗与急救流程培训讲解稿.docx' },
      { label: '📋 课后题库', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/临床常见急症标准化诊疗与急救流程/培训课后题（问卷星）.txt' },
      { label: '📊 效果评估', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/临床常见急症标准化诊疗与急救流程/培训效果评估.jpg' }
    ],
    keywords: ['急症', '急救', '标准化诊疗', '心肺复苏', '团队协作']
  },
  {
    id: 'm11',
    domain: 'clinical',
    title: 'DRG实施下的病案首页管理',
    subtitle: 'DRG分组逻辑·首页填写要点·编码质控',
    audience: ['dept', 'doctor'],
    targetDept: '病案室/全院医师',
    format: ['线下授课'],
    duration: 90,
    status: 'complete',
    month: 11,
    prerequisite: ['m04', 'm05'],
    filePaths: [
      { label: '📊 培训PPT', path: 'C:/Users/86132/Desktop/李爽的文件/ICD相关知识/DRG实施下的病案首页管理.pptx' }
    ],
    keywords: ['DRG', '病案首页', 'CMI', '入组率']
  },

  // ======================== 中医特色 ========================
  {
    id: 'm12',
    domain: 'tcm',
    title: '中风康复期针灸培训',
    subtitle: '中风辨证分型·针灸选穴方案·康复期综合管理',
    audience: ['dept'],
    targetDept: '针灸科/康复科',
    format: ['线下授课', '实操演练'],
    duration: 90,
    status: 'complete',
    month: 9,
    prerequisite: [],
    filePaths: [
      { label: '📊 培训PPTX', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/针灸培训-1/中风康复期针灸培训 (2)711··.pptx' },
      { label: '📝 教案', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/针灸培训-1/教案.docx' },
      { label: '🖼️ 课件图片(19页)', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/针灸培训-1/' }
    ],
    keywords: ['中风', '针灸', '康复期', '辨证取穴']
  },
  {
    id: 'm13',
    domain: 'tcm',
    title: '中医康复的临床路径与针灸治疗方案',
    subtitle: '康复临床路径标准化·针灸治疗规范化方案',
    audience: ['dept'],
    targetDept: '康复科/针灸科',
    format: ['线下授课'],
    duration: 90,
    status: 'complete',
    month: 11,
    prerequisite: ['m12'],
    filePaths: [
      { label: '📊 培训PPTX', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/临床路径-2/中医康复的临床路径与针灸治疗方案.pptx' },
      { label: '📝 教案', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/临床路径-2/教案(路径与方案).docx' }
    ],
    keywords: ['临床路径', '康复方案', '针灸治疗', '标准化']
  },

  // ======================== 制度规范 ========================
  {
    id: 'm14',
    domain: 'regulation',
    title: '十八项核心制度与优势病种培训',
    subtitle: '医疗质量安全核心制度要点·中医优势病种诊疗规范',
    audience: ['all'],
    format: ['线下授课', '考核测评'],
    duration: 120,
    status: 'framework',
    month: 10,
    prerequisite: [],
    filePaths: [
      { label: '📊 培训PPT', path: 'ppts/m14-十八项核心制度与优势病种.pptx' },
      { label: '📊 培训大纲', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/十八项核心制度与优势病种培训大纲.xlsx' }
    ],
    keywords: ['核心制度', '优势病种', '首诊负责', '三级查房', '会诊制度'],
    blueprintPath: 'plans/m14-核心制度培训-教学大纲.md'
  },
  {
    id: 'm15',
    domain: 'regulation',
    title: '岗前培训与考核',
    subtitle: '新员工入职培训体系：医院文化·规章制度·基本技能·考核标准',
    audience: ['newcomer'],
    format: ['线下授课', '实操演练', '考核测评'],
    duration: 480, // 多天
    status: 'framework',
    month: 7,
    prerequisite: [],
    filePaths: [
      { label: '📊 培训PPT', path: 'ppts/m15-岗前培训与考核.pptx' },
      { label: '📊 培训方案', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/岗前培训内容与考核方案.xlsx' },
      { label: '📊 新员工培训计划表', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/培训视频百日攻坚/新员工培训计划表.xlsx' }
    ],
    keywords: ['岗前培训', '新员工', '入职', '考核'],
    blueprintPath: 'plans/m15-岗前培训-教学大纲.md'
  },
  {
    id: 'm16',
    domain: 'regulation',
    title: '新版院内培训方案宣贯',
    subtitle: '全院培训体系说明·培训学分管理·培训纪律与考核挂钩',
    audience: ['all'],
    format: ['线下授课'],
    duration: 45,
    status: 'framework',
    month: 7,
    prerequisite: [],
    filePaths: [
      { label: '📊 培训PPT', path: 'ppts/m16-新版院内培训方案宣贯.pptx' },
      { label: '📊 院内培训方案', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/嘉和中医院新版院内培训方案.docx' },
      { label: '📊 培训大纲(百日攻坚)', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/培训视频百日攻坚/培训大纲.pdf' }
    ],
    keywords: ['培训体系', '学分', '考核', '百日攻坚'],
    blueprintPath: 'plans/m16-院内方案宣贯-教学大纲.md'
  },

  // ======================== 院感安全 ========================
  {
    id: 'm17',
    domain: 'infection',
    title: '院感防控与医疗废物管理',
    subtitle: '手卫生·无菌操作·消毒隔离·医疗废物分类处置',
    audience: ['all', 'doctor', 'nurse'],
    format: ['线下授课', '实操演练', '考核测评'],
    duration: 60,
    status: 'planned',
    month: 12,
    prerequisite: [],
    filePaths: [
      { label: '📊 培训PPT', path: 'ppts/m17-院感防控与医疗废物管理.pptx' }
    ],
    keywords: ['院感', '手卫生', '消毒', '医疗废物', '利器盒'],
    blueprintPath: 'plans/m17-院感防控-培训预案.md'
  },
  {
    id: 'm18',
    domain: 'infection',
    title: '职业暴露应急处置',
    subtitle: '针刺伤·血液体液暴露·应急流程·上报追踪',
    audience: ['all', 'nurse'],
    format: ['线下授课', '实操演练'],
    duration: 45,
    status: 'planned',
    month: 12,
    prerequisite: ['m17'],
    filePaths: [
      { label: '📊 培训PPT', path: 'ppts/m18-职业暴露应急处置.pptx' }
    ],
    keywords: ['职业暴露', '针刺伤', '应急', '上报'],
    blueprintPath: 'plans/m18-职业暴露-培训预案.md'
  },

  // ======================== 管理分析 ========================
  {
    id: 'm19',
    domain: 'regulation',
    title: '医疗管理部数据分析及6月工作计划',
    subtitle: '2026年上半年数据回顾·指标分析·6月工作部署',
    audience: ['dept'],
    targetDept: '医疗管理部/各科室主任',
    format: ['线下会议'],
    duration: 60,
    status: 'complete',
    month: 6,
    prerequisite: [],
    filePaths: [
      { label: '📊 会议PPTX', path: 'C:/Users/86132/Desktop/阿莲的文件/培训/6.5医疗管理部数据分析及6月工作计划.pptx' }
    ],
    keywords: ['数据分析', '工作计划', '医疗管理', '6月']
  }
];

// ======================== H2 2026 培训排期数据 ========================
const H2_PLAN = [
  { month: 6,  label: '6月', modules: ['m19'], note: '年中分析' },
  { month: 7,  label: '7月', modules: ['m08', 'm10', 'm15', 'm16'], note: '病历质控+急救+岗前+方案宣贯' },
  { month: 8,  label: '8月', modules: ['m01', 'm04', 'm05', 'm06', 'm07'], note: '医保合规月：飞检+ICD编码系列' },
  { month: 9,  label: '9月', modules: ['m02', 'm12'], note: '中医特色月：穴位埋线+中风针灸' },
  { month: 10, label: '10月', modules: ['m03', 'm14'], note: '心电图合规+核心制度' },
  { month: 11, label: '11月', modules: ['m11', 'm13'], note: 'DRG首页+康复临床路径' },
  { month: 12, label: '12月', modules: ['m17', 'm18'], note: '院感安全月+年度总结' }
];
